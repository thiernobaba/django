from django import forms
from responsable_filiere.models import Eleve
from responsable_classe.models import RenduProjet

class EleveProfileForm(forms.ModelForm):
    """Formulaire pour permettre à l'élève de modifier ses informations personnelles"""
    class Meta:
        model = Eleve
        fields = ['telephone', 'adresse', 'photo']
        widgets = {
            'adresse': forms.Textarea(attrs={'rows': 3}),
            'photo': forms.FileInput(),
        }

class RenduProjetForm(forms.ModelForm):
    """Formulaire pour soumettre un rendu de projet"""
    class Meta:
        model = RenduProjet
        fields = ['fichier_rendu', 'commentaire_eleve']
        widgets = {
            'commentaire_eleve': forms.Textarea(attrs={'rows': 3}),
            'fichier_rendu': forms.FileInput(),
        }