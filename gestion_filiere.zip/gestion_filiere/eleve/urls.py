from django.urls import path
from . import views

app_name = 'eleve'

urlpatterns = [
    path('', views.EleveDashboardView.as_view(), name='dashboard'),
    path('profile/', views.EleveProfileView.as_view(), name='profile'),
    path('profile/modifier/', views.EleveProfileUpdateView.as_view(), name='profile_update'),
    path('notes/', views.NoteListView.as_view(), name='note_list'),
    path('absences/', views.AbsenceListView.as_view(), name='absence_list'),
    path('projets/', views.ProjetListView.as_view(), name='projet_list'),
    path('projets/<int:pk>/', views.ProjetDetailView.as_view(), name='projet_detail'),
    path('projets/<int:projet_id>/soumettre/', views.RenduProjetCreateView.as_view(), name='rendu_projet_create'),
    path('observations/', views.ObservationListView.as_view(), name='observation_list'),
    path('retards/', views.RetardListView.as_view(), name='retard_list'),
    path('cahier-texte/', views.CahierTexteListView.as_view(), name='cahier_texte_list'),
]