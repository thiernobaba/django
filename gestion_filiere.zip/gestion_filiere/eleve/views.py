from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import TemplateView, ListView, DetailView, CreateView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from responsable_filiere.models import Eleve, Note, Absence, Projet, CahierTexte
from responsable_classe.models import RenduProjet, Observation, Retard
from .forms import EleveProfileForm, RenduProjetForm
from django.http import HttpResponseRedirect
from django.db.models import Avg

class EleveDashboardView(LoginRequiredMixin, TemplateView):
    template_name = 'eleve/dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        eleve = Eleve.objects.get(email=self.request.user.email)
        
        # Statistiques
        context['eleve'] = eleve
        context['total_notes'] = Note.objects.filter(eleve=eleve).count()
        context['moyenne_generale'] = Note.objects.filter(eleve=eleve).aggregate(Avg('valeur'))['valeur__avg'] or 0
        context['total_absences'] = Absence.objects.filter(eleve=eleve).count()
        context['projets_en_cours'] = Projet.objects.filter(classe=eleve.classe, statut__in=['ATTRIBUE', 'EN_COURS']).count()
        context['retards'] = Retard.objects.filter(eleve=eleve).count()
        
        # Projets à venir (prochains 7 jours)
        date_limite = timezone.now().date() + timezone.timedelta(days=7)
        context['projets_urgents'] = Projet.objects.filter(
            classe=eleve.classe,
            date_limite__lte=date_limite,
            statut__in=['ATTRIBUE', 'EN_COURS']
        ).order_by('date_limite')[:5]
        
        # Dernières observations
        context['dernieres_observations'] = Observation.objects.filter(eleve=eleve).order_by('-date')[:5]
        
        return context

class EleveProfileView(LoginRequiredMixin, DetailView):
    model = Eleve
    template_name = 'eleve/profile.html'
    context_object_name = 'eleve'

    def get_object(self):
        return get_object_or_404(Eleve, email=self.request.user.email)

class EleveProfileUpdateView(LoginRequiredMixin, UpdateView):
    model = Eleve
    form_class = EleveProfileForm
    template_name = 'eleve/profile_form.html'
    success_url = reverse_lazy('eleve:profile')

    def get_object(self):
        return get_object_or_404(Eleve, email=self.request.user.email)

class NoteListView(LoginRequiredMixin, ListView):
    model = Note
    template_name = 'eleve/note_list.html'
    context_object_name = 'notes'

    def get_queryset(self):
        eleve = get_object_or_404(Eleve, email=self.request.user.email)
        queryset = Note.objects.filter(eleve=eleve).select_related('matiere').order_by('-date')
        matiere_id = self.request.GET.get('matiere')
        date_debut = self.request.GET.get('date_debut')
        date_fin = self.request.GET.get('date_fin')
        if matiere_id:
            queryset = queryset.filter(matiere_id=matiere_id)
        if date_debut:
            queryset = queryset.filter(date__gte=date_debut)
        if date_fin:
            queryset = queryset.filter(date__lte=date_fin)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        eleve = get_object_or_404(Eleve, email=self.request.user.email)
        context['matieres'] = eleve.classe.matieres.all()
        return context

class AbsenceListView(LoginRequiredMixin, ListView):
    model = Absence
    template_name = 'eleve/absence_list.html'
    context_object_name = 'absences'

    def get_queryset(self):
        eleve = get_object_or_404(Eleve, email=self.request.user.email)
        queryset = Absence.objects.filter(eleve=eleve).select_related('matiere').order_by('-date')
        date_debut = self.request.GET.get('date_debut')
        date_fin = self.request.GET.get('date_fin')
        if date_debut:
            queryset = queryset.filter(date__gte=date_debut)
        if date_fin:
            queryset = queryset.filter(date__lte=date_fin)
        return queryset

class ProjetListView(LoginRequiredMixin, ListView):
    model = Projet
    template_name = 'eleve/projet_list.html'
    context_object_name = 'projets'

    def get_queryset(self):
        eleve = get_object_or_404(Eleve, email=self.request.user.email)
        queryset = Projet.objects.filter(classe=eleve.classe).select_related('matiere').order_by('date_limite')
        statut = self.request.GET.get('statut')
        if statut:
            queryset = queryset.filter(statut=statut)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['statuts'] = Projet.STATUT_CHOICES
        return context

class ProjetDetailView(LoginRequiredMixin, DetailView):
    model = Projet
    template_name = 'eleve/projet_detail.html'
    context_object_name = 'projet'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        eleve = get_object_or_404(Eleve, email=self.request.user.email)
        context['rendu'] = RenduProjet.objects.filter(projet=self.object, eleve=eleve).first()
        return context

class RenduProjetCreateView(LoginRequiredMixin, CreateView):
    model = RenduProjet
    form_class = RenduProjetForm
    template_name = 'eleve/rendu_projet_form.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['projet'] = get_object_or_404(Projet, pk=self.kwargs['projet_id'])
        return context

    def form_valid(self, form):
        eleve = get_object_or_404(Eleve, email=self.request.user.email)
        projet = get_object_or_404(Projet, pk=self.kwargs['projet_id'])
        form.instance.eleve = eleve
        form.instance.projet = projet
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('eleve:projet_detail', kwargs={'pk': self.kwargs['projet_id']})

class ObservationListView(LoginRequiredMixin, ListView):
    model = Observation
    template_name = 'eleve/observation_list.html'
    context_object_name = 'observations'

    def get_queryset(self):
        eleve = get_object_or_404(Eleve, email=self.request.user.email)
        queryset = Observation.objects.filter(eleve=eleve).select_related('matiere').order_by('-date')
        type_obs = self.request.GET.get('type')
        if type_obs:
            queryset = queryset.filter(type_observation=type_obs)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['types'] = Observation.TYPE_OBSERVATION_CHOICES
        return context

class RetardListView(LoginRequiredMixin, ListView):
    model = Retard
    template_name = 'eleve/retard_list.html'
    context_object_name = 'retards'

    def get_queryset(self):
        eleve = get_object_or_404(Eleve, email=self.request.user.email)
        queryset = Retard.objects.filter(eleve=eleve).select_related('matiere').order_by('-date')
        date_debut = self.request.GET.get('date_debut')
        date_fin = self.request.GET.get('date_fin')
        if date_debut:
            queryset = queryset.filter(date__gte=date_debut)
        if date_fin:
            queryset = queryset.filter(date__lte=date_fin)
        return queryset

class CahierTexteListView(LoginRequiredMixin, ListView):
    model = CahierTexte
    template_name = 'eleve/cahier_texte_list.html'
    context_object_name = 'cahiers'

    def get_queryset(self):
        eleve = get_object_or_404(Eleve, email=self.request.user.email)
        queryset = CahierTexte.objects.filter(classe=eleve.classe).select_related('matiere').order_by('-date')
        date_debut = self.request.GET.get('date_debut')
        date_fin = self.request.GET.get('date_fin')
        if date_debut:
            queryset = queryset.filter(date__gte=date_debut)
        if date_fin:
            queryset = queryset.filter(date__lte=date_fin)
        return queryset