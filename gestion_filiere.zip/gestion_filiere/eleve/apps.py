from django.apps import AppConfig

class EleveConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eleve'
    verbose_name = 'Portail Élève'