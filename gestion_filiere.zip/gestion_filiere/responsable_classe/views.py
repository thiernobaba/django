# responsable_classe/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import (
    ListView, DetailView, CreateView, UpdateView, DeleteView, TemplateView
)
from django.db.models import Count, Q, Avg
from django.http import JsonResponse, HttpResponse
from django.utils import timezone
from datetime import datetime, timedelta, date
import pandas as pd
from io import BytesIO
import xlsxwriter

from .models import CahierTexte, Absence, Projet, RenduProjet, Retard, Observation
from responsable_classe.forms import (
    CahierTexteForm, AbsenceForm, AbsenceMultipleForm, ProjetForm, 
    RenduProjetForm, RetardForm, ObservationForm, ClasseSelectForm, 
    FiltreDateForm
)
from responsable_filiere.models import Classe, Eleve, Matiere


class DashboardView(TemplateView):
    """Vue du tableau de bord pour le responsable de classe"""
    template_name = 'responsable_classe/dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        today = timezone.now().date()
        
        # Statistiques générales
        context['total_cahiers'] = CahierTexte.objects.count()
        context['absences_non_justifiees'] = Absence.objects.filter(justifiee=False).count()
        context['projets_en_cours'] = Projet.objects.filter(
            statut__in=['ATTRIBUE', 'EN_COURS']
        ).count()
        context['retards_aujourd_hui'] = Retard.objects.filter(date=today).count()
        
        # Projets à échéance proche (7 jours)
        date_limite = today + timedelta(days=7)
        context['projets_urgents'] = Projet.objects.filter(
            date_limite__lte=date_limite,
            statut__in=['ATTRIBUE', 'EN_COURS']
        ).order_by('date_limite')[:5]
        
        # Dernières observations
        context['dernieres_observations'] = Observation.objects.select_related(
            'eleve', 'matiere'
        ).order_by('-date')[:5]
        
        # Absences récentes non justifiées
        context['absences_recentes'] = Absence.objects.filter(
            justifiee=False
        ).select_related('eleve', 'matiere').order_by('-date')[:5]
        
        return context


# === CAHIER DE TEXTE ===
class CahierTexteListView(ListView):
    model = CahierTexte
    template_name = 'responsable_classe/cahier_texte_list.html'
    context_object_name = 'cahiers'
    paginate_by = 10
    
    def get_queryset(self):
        queryset = super().get_queryset()
        classe_id = self.request.GET.get('classe')
        date_debut = self.request.GET.get('date_debut')
        date_fin = self.request.GET.get('date_fin')
        
        if classe_id:
            queryset = queryset.filter(classe_id=classe_id)
        if date_debut:
            queryset = queryset.filter(date__gte=date_debut)
        if date_fin:
            queryset = queryset.filter(date__lte=date_fin)
            
        return queryset.select_related('classe', 'matiere')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form'] = FiltreDateForm(self.request.GET or None)
        return context


class CahierTexteDetailView(DetailView):
    model = CahierTexte
    template_name = 'responsable_classe/cahier_texte_detail.html'
    context_object_name = 'cahier'


class CahierTexteCreateView(CreateView):
    model = CahierTexte
    form_class = CahierTexteForm
    template_name = 'responsable_classe/cahier_texte_form.html'
    success_url = reverse_lazy('responsable_classe:cahier_texte_list')


class CahierTexteUpdateView(UpdateView):
    model = CahierTexte
    form_class = CahierTexteForm
    template_name = 'responsable_classe/cahier_texte_form.html'
    
    def get_success_url(self):
        return reverse_lazy('responsable_classe:cahier_texte_detail', kwargs={'pk': self.object.pk})


class CahierTexteDeleteView(DeleteView):
    model = CahierTexte
    template_name = 'responsable_classe/cahier_texte_confirm_delete.html'
    success_url = reverse_lazy('responsable_classe:cahier_texte_list')


# === ABSENCES ===
def absence_list(request):
    """Liste des absences avec filtrage"""
    form = FiltreDateForm(request.GET or None)
    absences = Absence.objects.select_related('eleve', 'matiere')
    
    if form.is_valid():
        classe = form.cleaned_data.get('classe')
        date_debut = form.cleaned_data.get('date_debut')
        date_fin = form.cleaned_data.get('date_fin')
        
        if classe:
            absences = absences.filter(eleve__classe=classe)
        if date_debut:
            absences = absences.filter(date__gte=date_debut)
        if date_fin:
            absences = absences.filter(date__lte=date_fin)
    
    absences = absences.order_by('-date', '-heure_debut')
    
    return render(request, 'responsable_classe/absence_list.html', {
        'absences': absences,
        'form': form
    })


def absence_create(request):
    """Créer une absence"""
    if request.method == 'POST':
        form = AbsenceForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('responsable_classe:absence_list')
    else:
        form = AbsenceForm()
    
    return render(request, 'responsable_classe/absence_form.html', {
        'form': form,
        'title': 'Créer une absence'
    })


def absence_multiple_create(request):
    """Créer plusieurs absences en une fois"""
    if request.method == 'POST':
        form = AbsenceMultipleForm(request.POST)
        if form.is_valid():
            eleves = form.cleaned_data['eleves']
            for eleve in eleves:
                Absence.objects.create(
                    eleve=eleve,
                    date=form.cleaned_data['date'],
                    matiere=form.cleaned_data['matiere'],
                    type_absence=form.cleaned_data['type_absence'],
                    heure_debut=form.cleaned_data['heure_debut'],
                    heure_fin=form.cleaned_data['heure_fin']
                )
            return redirect('responsable_classe:absence_list')
    else:
        form = AbsenceMultipleForm()
    
    return render(request, 'responsable_classe/absence_multiple_form.html', {
        'form': form,
        'title': 'Marquer plusieurs absences'
    })


class AbsenceUpdateView(UpdateView):
    model = Absence
    form_class = AbsenceForm
    template_name = 'responsable_classe/absence_form.html'
    success_url = reverse_lazy('responsable_classe:absence_list')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Modifier une absence'
        return context


class AbsenceDeleteView(DeleteView):
    model = Absence
    template_name = 'responsable_classe/absence_confirm_delete.html'
    success_url = reverse_lazy('responsable_classe:absence_list')


def rapport_absences(request):
    """Génère un rapport d'absences au format Excel"""
    # Récupération des paramètres de filtrage
    classe_id = request.GET.get('classe')
    date_debut = request.GET.get('date_debut')
    date_fin = request.GET.get('date_fin')
    
    # Construction de la requête
    queryset = Absence.objects.select_related('eleve', 'matiere', 'eleve__classe')
    
    if classe_id:
        queryset = queryset.filter(eleve__classe_id=classe_id)
    if date_debut:
        queryset = queryset.filter(date__gte=date_debut)
    if date_fin:
        queryset = queryset.filter(date__lte=date_fin)
    
    # Création du fichier Excel
    output = BytesIO()
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet('Rapport Absences')
    
    # En-têtes
    headers = [
        'Élève', 'Classe', 'Date', 'Matière', 'Type', 
        'Heure début', 'Heure fin', 'Durée (min)', 
        'Justifiée', 'Motif'
    ]
    
    for col, header in enumerate(headers):
        worksheet.write(0, col, header)
    
    # Données
    for row, absence in enumerate(queryset, 1):
        worksheet.write(row, 0, str(absence.eleve))
        worksheet.write(row, 1, str(absence.eleve.classe))
        worksheet.write(row, 2, absence.date.strftime('%d/%m/%Y'))
        worksheet.write(row, 3, str(absence.matiere))
        worksheet.write(row, 4, absence.get_type_absence_display())
        worksheet.write(row, 5, absence.heure_debut.strftime('%H:%M'))
        worksheet.write(row, 6, absence.heure_fin.strftime('%H:%M'))
        worksheet.write(row, 7, absence.duree_minutes)
        worksheet.write(row, 8, 'Oui' if absence.justifiee else 'Non')
        worksheet.write(row, 9, absence.motif or '')
    
    workbook.close()
    output.seek(0)
    
    # Réponse HTTP
    response = HttpResponse(
        output.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename="rapport_absences_{timezone.now().strftime("%Y%m%d")}.xlsx"'
    
    return response


# === PROJETS ===
class ProjetListView(ListView):
    model = Projet
    template_name = 'responsable_classe/projet_list.html'
    context_object_name = 'projets'
    paginate_by = 10
    
    def get_queryset(self):
        queryset = super().get_queryset()
        statut = self.request.GET.get('statut')
        classe_id = self.request.GET.get('classe')
        
        if statut:
            queryset = queryset.filter(statut=statut)
        if classe_id:
            queryset = queryset.filter(classe_id=classe_id)
            
        return queryset.select_related('classe', 'matiere')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['statuts'] = Projet.STATUT_CHOICES
        context['classes'] = Classe.objects.all()
        return context


class ProjetDetailView(DetailView):
    model = Projet
    template_name = 'responsable_classe/projet_detail.html'
    context_object_name = 'projet'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Récupération des rendus pour ce projet
        context['rendus'] = RenduProjet.objects.filter(
            projet=self.object
        ).select_related('eleve').order_by('date_rendu')
        
        # Statistiques
        total_eleves = self.object.classe.eleves.count()
        rendus_count = context['rendus'].count()
        context['stats'] = {
            'total_eleves': total_eleves,
            'rendus_count': rendus_count,
            'taux_rendu': (rendus_count / total_eleves * 100) if total_eleves > 0 else 0
        }
        
        return context


class ProjetCreateView(CreateView):
    model = Projet
    form_class = ProjetForm
    template_name = 'responsable_classe/projet_form.html'
    success_url = reverse_lazy('responsable_classe:projet_list')


class ProjetUpdateView(UpdateView):
    model = Projet
    form_class = ProjetForm
    template_name = 'responsable_classe/projet_form.html'
    
    def get_success_url(self):
        return reverse_lazy('responsable_classe:projet_detail', kwargs={'pk': self.object.pk})


class ProjetDeleteView(DeleteView):
    model = Projet
    template_name = 'responsable_classe/projet_confirm_delete.html'
    success_url = reverse_lazy('responsable_classe:projet_list')


def corriger_rendus(request, projet_id):
    """Interface de correction des rendus d'un projet"""
    projet = get_object_or_404(Projet, id=projet_id)
    rendus = RenduProjet.objects.filter(projet=projet).select_related('eleve')
    
    if request.method == 'POST':
        # Traitement des corrections
        for rendu in rendus:
            note = request.POST.get(f'note_{rendu.id}')
            commentaire = request.POST.get(f'commentaire_{rendu.id}')
            
            if note:
                rendu.note = float(note)
                rendu.commentaire_professeur = commentaire
                rendu.date_correction = timezone.now()
                rendu.save()
        
        # Mise à jour du statut du projet
        projet.statut = 'CORRIGE'
        projet.save()
        
        return redirect('responsable_classe:projet_detail', pk=projet.id)
    
    return render(request, 'responsable_classe/corriger_rendus.html', {
        'projet': projet,
        'rendus': rendus
    })


# === RETARDS ===
def retard_list(request):
    """Liste des retards avec filtrage"""
    form = FiltreDateForm(request.GET or None)
    retards = Retard.objects.select_related('eleve', 'matiere')
    
    if form.is_valid():
        classe = form.cleaned_data.get('classe')
        date_debut = form.cleaned_data.get('date_debut')
        date_fin = form.cleaned_data.get('date_fin')
        
        if classe:
            retards = retards.filter(eleve__classe=classe)
        if date_debut:
            retards = retards.filter(date__gte=date_debut)
        if date_fin:
            retards = retards.filter(date__lte=date_fin)
    
    retards = retards.order_by('-date', '-heure_arrivee')
    
    return render(request, 'responsable_classe/retard_list.html', {
        'retards': retards,
        'form': form
    })


def retard_create(request):
    """Créer un retard"""
    if request.method == 'POST':
        form = RetardForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('responsable_classe:retard_list')
    else:
        form = RetardForm()
    
    return render(request, 'responsable_classe/retard_form.html', {
        'form': form,
        'title': 'Enregistrer un retard'
    })


class RetardUpdateView(UpdateView):
    model = Retard
    form_class = RetardForm
    template_name = 'responsable_classe/retard_form.html'
    success_url = reverse_lazy('responsable_classe:retard_list')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Modifier un retard'
        return context


class RetardDeleteView(DeleteView):
    model = Retard
    template_name = 'responsable_classe/retard_confirm_delete.html'
    success_url = reverse_lazy('responsable_classe:retard_list')


# === OBSERVATIONS ===
class ObservationListView(ListView):
    model = Observation
    template_name = 'responsable_classe/observation_list.html'
    context_object_name = 'observations'
    paginate_by = 10
    
    def get_queryset(self):
        queryset = super().get_queryset()
        type_obs = self.request.GET.get('type')
        classe_id = self.request.GET.get('classe')
        
        if type_obs:
            queryset = queryset.filter(type_observation=type_obs)
        if classe_id:
            queryset = queryset.filter(eleve__classe_id=classe_id)
            
        return queryset.select_related('eleve', 'matiere', 'eleve__classe')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['types'] = Observation.TYPE_OBSERVATION_CHOICES
        context['classes'] = Classe.objects.all()
        return context


class ObservationDetailView(DetailView):
    model = Observation
    template_name = 'responsable_classe/observation_detail.html'
    context_object_name = 'observation'


class ObservationCreateView(CreateView):
    model = Observation
    form_class = ObservationForm
    template_name = 'responsable_classe/observation_form.html'
    success_url = reverse_lazy('responsable_classe:observation_list')


class ObservationUpdateView(UpdateView):
    model = Observation
    form_class = ObservationForm
    template_name = 'responsable_classe/observation_form.html'
    
    def get_success_url(self):
        return reverse_lazy('responsable_classe:observation_detail', kwargs={'pk': self.object.pk})


class ObservationDeleteView(DeleteView):
    model = Observation
    template_name = 'responsable_classe/observation_confirm_delete.html'
    success_url = reverse_lazy('responsable_classe:observation_list')


# === STATISTIQUES ET RAPPORTS ===
def statistiques_classe(request):
    """Page de statistiques pour les classes"""
    form = ClasseSelectForm(request.GET or None)
    stats = {}
    
    if form.is_valid() and form.cleaned_data.get('classe'):
        classe = form.cleaned_data['classe']
        
        # Période (30 derniers jours)
        date_fin = timezone.now().date()
        date_debut = date_fin - timedelta(days=30)
        
        # Statistiques d'absences
        absences = Absence.objects.filter(
            eleve__classe=classe,
            date__range=[date_debut, date_fin]
        )
        
        stats['absences'] = {
            'total': absences.count(),
            'justifiees': absences.filter(justifiee=True).count(),
            'non_justifiees': absences.filter(justifiee=False).count(),
            'par_eleve': absences.values('eleve__nom', 'eleve__prenom').annotate(
                total=Count('id')
            ).order_by('-total')[:5]
        }
        
        # Statistiques de retards
        retards = Retard.objects.filter(
            eleve__classe=classe,
            date__range=[date_debut, date_fin]
        )
        
        stats['retards'] = {
            'total': retards.count(),
            'justifies': retards.filter(justifie=True).count(),
            'par_eleve': retards.values('eleve__nom', 'eleve__prenom').annotate(
                total=Count('id')
            ).order_by('-total')[:5]
        }
        
        # Statistiques de projets
        projets = Projet.objects.filter(classe=classe)
        rendus = RenduProjet.objects.filter(
            projet__classe=classe,
            date_rendu__date__range=[date_debut, date_fin]
        )
        
        stats['projets'] = {
            'total': projets.count(),
            'en_cours': projets.filter(statut__in=['ATTRIBUE', 'EN_COURS']).count(),
            'corriges': projets.filter(statut='CORRIGE').count(),
            'note_moyenne': rendus.aggregate(Avg('note'))['note__avg'] or 0,
            'taux_rendu': (rendus.count() / (projets.count() * classe.eleves.count()) * 100) 
                         if projets.count() > 0 and classe.eleves.count() > 0 else 0
        }
        
        # Observations
        observations = Observation.objects.filter(
            eleve__classe=classe,
            date__range=[date_debut, date_fin]
        )
        
        stats['observations'] = {
            'total': observations.count(),
            'positives': observations.filter(type_observation='POSITIVE').count(),
            'negatives': observations.filter(type_observation='NEGATIVE').count(),
            'disciplinaires': observations.filter(type_observation='DISCIPLINAIRE').count()
        }
    
    return render(request, 'responsable_classe/statistiques.html', {
        'form': form,
        'stats': stats
    })


def ajax_eleves_classe(request):
    """Retourne la liste des élèves d'une classe en AJAX"""
    classe_id = request.GET.get('classe_id')
    if classe_id:
        eleves = Eleve.objects.filter(classe_id=classe_id).values('id', 'nom', 'prenom')
        return JsonResponse({'eleves': list(eleves)})
    return JsonResponse({'eleves': []})