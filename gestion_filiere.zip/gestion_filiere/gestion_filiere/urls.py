# gestion_scolaire/urls.py

from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('res_filiere', include('responsable_filiere.urls')),
    path('res_classe/', include('responsable_classe.urls')),
    path('eleve/', include('eleve.urls')),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(template_name='logout.html'), name='logout'),
]