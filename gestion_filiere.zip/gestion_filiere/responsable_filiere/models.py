# responsable_filiere/models.py

from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class Classe(models.Model):
    """Modèle représentant une classe (AS1, AS2, AS3)"""
    NIVEAU_CHOICES = [
        ('AS1', 'Analyse Statistique 1'),
        ('AS2', 'Analyse Statistique 2'),
        ('AS3', 'Analyse Statistique 3'),
    ]
    
    niveau = models.CharField(max_length=3, choices=NIVEAU_CHOICES, unique=True)
    description = models.TextField(blank=True)
    
    class Meta:
        verbose_name = "Classe"
        verbose_name_plural = "Classes"
    
    def __str__(self):
        return self.get_niveau_display()  # Affiche le nom complet au lieu du code


class Eleve(models.Model):
    """Modèle représentant un élève"""
    SEXE_CHOICES = [
        ('M', 'Masculin'),
        ('F', 'Féminin'),
    ]
    
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    date_naissance = models.DateField()
    sexe = models.CharField(max_length=1, choices=SEXE_CHOICES)
    email = models.EmailField(unique=True)
    telephone = models.CharField(max_length=15, blank=True)
    adresse = models.TextField(blank=True)
    # CORRECTION: Supprimez choices= sur une ForeignKey
    classe = models.ForeignKey(Classe, on_delete=models.CASCADE, related_name='eleves')
    photo = models.ImageField(upload_to='photos_eleves/', blank=True, null=True)
    date_inscription = models.DateField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Élève"
        verbose_name_plural = "Élèves"
        ordering = ['nom', 'prenom']
    
    def __str__(self):
        return f"{self.nom} {self.prenom} ({self.classe})"
    
    @property
    def nom_complet(self):
        return f"{self.nom} {self.prenom}"

class Matiere(models.Model):
    """Modèle représentant une matière enseignée"""
    nom = models.CharField(max_length=100)
    code = models.CharField(max_length=10, unique=True)
    coefficient = models.PositiveIntegerField(default=1)
    description = models.TextField(blank=True)
    classes = models.ManyToManyField(Classe, related_name='matieres')
    
    class Meta:
        verbose_name = "Matière"
        verbose_name_plural = "Matières"
        
    def __str__(self):
        return f"{self.code} - {self.nom}"


class Note(models.Model):
    """Modèle représentant une note d'un élève dans une matière"""
    eleve = models.ForeignKey(Eleve, on_delete=models.CASCADE, related_name='notes')
    matiere = models.ForeignKey(Matiere, on_delete=models.CASCADE, related_name='notes')
    valeur = models.DecimalField(
        max_digits=4, 
        decimal_places=2,
        validators=[MinValueValidator(0), MaxValueValidator(20)]
    )
    date = models.DateField()
    type_evaluation = models.CharField(
        max_length=20,
        choices=[
            ('DEVOIR', 'Devoir'),
            ('EXAMEN', 'Examen'),
            ('TP', 'Travail Pratique'),
            ('PROJET', 'Projet'),
        ]
    )
    commentaire = models.TextField(blank=True)
    
    class Meta:
        verbose_name = "Note"
        verbose_name_plural = "Notes"
        # Contrainte unique pour éviter les doublons pour une même évaluation
        unique_together = ['eleve', 'matiere', 'date', 'type_evaluation']
        
    def __str__(self):
        return f"{self.eleve} - {self.matiere} - {self.valeur}/20 ({self.type_evaluation})"


class CahierTexte(models.Model):
    """Modèle pour le cahier de texte (sera utilisé par le responsable de classe)"""
    classe = models.ForeignKey(Classe, on_delete=models.CASCADE, related_name='cahiers_texte')
    matiere = models.ForeignKey(Matiere, on_delete=models.CASCADE, related_name='cahiers_texte')
    date = models.DateField()
    contenu = models.TextField()
    
    class Meta:
        verbose_name = "Cahier de texte"
        verbose_name_plural = "Cahiers de texte"
        ordering = ['-date']


class Absence(models.Model):
    """Modèle pour les absences (sera utilisé par le responsable de classe)"""
    eleve = models.ForeignKey(Eleve, on_delete=models.CASCADE, related_name='absences')
    date = models.DateField()
    justifiee = models.BooleanField(default=False)
    motif = models.TextField(blank=True)
    
    class Meta:
        verbose_name = "Absence"
        verbose_name_plural = "Absences"
        ordering = ['-date']


class Projet(models.Model):
    """Modèle pour les projets et devoirs à rendre"""
    titre = models.CharField(max_length=200)
    description = models.TextField()
    matiere = models.ForeignKey(Matiere, on_delete=models.CASCADE, related_name='projets')
    classe = models.ForeignKey(Classe, on_delete=models.CASCADE, related_name='projets')
    date_attribution = models.DateField()
    date_limite = models.DateField()
    
    class Meta:
        verbose_name = "Projet"
        verbose_name_plural = "Projets"
        ordering = ['date_limite']
        
    def __str__(self):
        return f"{self.titre} ({self.classe}) - Échéance: {self.date_limite}"