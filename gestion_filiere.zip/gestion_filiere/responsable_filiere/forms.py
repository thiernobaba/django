# responsable_filiere/forms.py

from django import forms
from .models import Eleve, Matiere, Note, Classe
from django.forms import inlineformset_factory

class EleveForm(forms.ModelForm):
    """Formulaire pour la création et modification d'un élève"""
    class Meta:
        model = Eleve
        fields = ['nom', 'prenom', 'date_naissance', 'sexe', 'email', 
                  'telephone', 'adresse', 'classe', 'photo']
        widgets = {
            'date_naissance': forms.DateInput(attrs={'type': 'date'}),
            'adresse': forms.Textarea(attrs={'rows': 3}),
        }


class MatiereForm(forms.ModelForm):
    """Formulaire pour la création et modification d'une matière"""
    class Meta:
        model = Matiere
        fields = ['nom', 'code', 'coefficient', 'description', 'classes']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
            'classes': forms.CheckboxSelectMultiple(),
        }


class NoteForm(forms.ModelForm):
    """Formulaire pour la saisie d'une note"""
    class Meta:
        model = Note
        fields = ['eleve', 'matiere', 'valeur', 'date', 'type_evaluation', 'commentaire']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'commentaire': forms.Textarea(attrs={'rows': 2}),
        }


class NoteMultipleForm(forms.Form):
    """Formulaire pour la saisie de notes pour plusieurs élèves d'une classe"""
    classe = forms.ModelChoiceField(queryset=Classe.objects.all())
    matiere = forms.ModelChoiceField(queryset=Matiere.objects.all())
    date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    type_evaluation = forms.ChoiceField(choices=Note._meta.get_field('type_evaluation').choices)


class EleveSelectForm(forms.Form):
    """Formulaire pour sélectionner une classe et voir les élèves"""
    classe = forms.ModelChoiceField(
        queryset=Classe.objects.all(),
        empty_label="Sélectionnez une classe",
        widget=forms.Select(attrs={'class': 'form-select'})
    )


class MatiereSelectForm(forms.Form):
    """Formulaire pour filtrer les matières par classe"""
    classe = forms.ModelChoiceField(
        queryset=Classe.objects.all(),
        empty_label="Toutes les classes",
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )


# Formulaire dynamique pour saisir les notes de plusieurs élèves à la fois
NoteFormSet = inlineformset_factory(
    Matiere, 
    Note, 
    fields=('eleve', 'valeur', 'commentaire'),
    extra=1,
    can_delete=False
)