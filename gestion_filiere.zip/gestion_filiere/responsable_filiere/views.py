# responsable_filiere/views.py (version sans authentification)

from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView, TemplateView
# Supprimez ces imports d'authentification :
# from django.contrib.auth.mixins import LoginRequiredMixin
# from django.contrib.auth.decorators import login_required
from django.forms import formset_factory
from django.db.models import Avg, Count
from django.http import HttpResponse
import pandas as pd
import xlsxwriter
from io import BytesIO

from responsable_classe.models import Eleve, Matiere, Classe, CahierTexte, Absence, Projet
from .forms import (
    EleveForm, MatiereForm, NoteForm, EleveSelectForm, 
    MatiereSelectForm, NoteMultipleForm, NoteFormSet,Note
)

# Vue du tableau de bord (sans LoginRequiredMixin)
class DashboardView(TemplateView):
    template_name = 'responsable_filiere/dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Statistiques générales
        context['total_eleves'] = Eleve.objects.count()
        context['total_classes'] = Classe.objects.count()
        context['total_matieres'] = Matiere.objects.count()
        
        # Répartition des élèves par classe
        context['eleves_par_classe'] = Classe.objects.annotate(
            nb_eleves=Count('eleves')
        ).values('niveau', 'nb_eleves')
        
        # Projets à venir
        context['projets_a_venir'] = Projet.objects.order_by('date_limite')[:5]
        
        return context

# Vues pour la gestion des élèves (sans LoginRequiredMixin)
class EleveListView(ListView):
    model = Eleve
    template_name = 'responsable_filiere/eleve_list.html'
    context_object_name = 'eleves'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form'] = EleveSelectForm(self.request.GET or None)
        return context
    
    def get_queryset(self):
        queryset = super().get_queryset()
        classe_id = self.request.GET.get('classe')
        
        if classe_id:
            queryset = queryset.filter(classe_id=classe_id)
        
        return queryset

class EleveDetailView(DetailView):
    model = Eleve
    template_name = 'responsable_filiere/eleve_detail.html'
    context_object_name = 'eleve'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        eleve = self.get_object()
        
        # Récupérer les notes de l'élève
        context['notes'] = Note.objects.filter(eleve=eleve).order_by('matiere')
        
        # Moyenne générale
        moyenne_generale = Note.objects.filter(eleve=eleve).aggregate(Avg('valeur'))
        context['moyenne_generale'] = moyenne_generale['valeur__avg']
        
        # Absences
        context['absences'] = Absence.objects.filter(eleve=eleve).order_by('-date')
        
        return context

class EleveCreateView(CreateView):
    model = Eleve
    form_class = EleveForm
    template_name = 'responsable_filiere/eleve_form.html'
    success_url = reverse_lazy('responsable_filiere:eleve_list')

class EleveUpdateView(UpdateView):
    model = Eleve
    form_class = EleveForm
    template_name = 'responsable_filiere/eleve_form.html'
    
    def get_success_url(self):
        return reverse_lazy('responsable_filiere:eleve_detail', kwargs={'pk': self.object.pk})

class EleveDeleteView(DeleteView):
    model = Eleve
    template_name = 'responsable_filiere/eleve_confirm_delete.html'
    success_url = reverse_lazy('responsable_filiere:eleve_list')

# Vues pour la gestion des matières (sans LoginRequiredMixin)
class MatiereListView(ListView):
    model = Matiere
    template_name = 'responsable_filiere/matiere_list.html'
    context_object_name = 'matieres'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form'] = MatiereSelectForm(self.request.GET or None)
        return context
    
    def get_queryset(self):
        queryset = super().get_queryset()
        classe_id = self.request.GET.get('classe')
        
        if classe_id:
            queryset = queryset.filter(classes__id=classe_id)
        
        return queryset

class MatiereDetailView(DetailView):
    model = Matiere
    template_name = 'responsable_filiere/matiere_detail.html'
    context_object_name = 'matiere'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        matiere = self.get_object()
        
        # Classes où cette matière est enseignée
        context['classes'] = matiere.classes.all()
        
        return context

class MatiereCreateView(CreateView):
    model = Matiere
    form_class = MatiereForm
    template_name = 'responsable_filiere/matiere_form.html'
    success_url = reverse_lazy('responsable_filiere:matiere_list')

class MatiereUpdateView(UpdateView):
    model = Matiere
    form_class = MatiereForm
    template_name = 'responsable_filiere/matiere_form.html'
    
    def get_success_url(self):
        return reverse_lazy('responsable_filiere:matiere_detail', kwargs={'pk': self.object.pk})

class MatiereDeleteView(DeleteView):
    model = Matiere
    template_name = 'responsable_filiere/matiere_confirm_delete.html'
    success_url = reverse_lazy('responsable_filiere:matiere_list')

# Vues pour la gestion des notes (sans @login_required)
def note_list(request):
    """Liste des notes avec possibilité de filtrer par classe et matière"""
    form = None
    notes = Note.objects.none()  # Queryset vide par défaut
    
    if request.method == 'GET' and ('classe' in request.GET or 'matiere' in request.GET):
        form = NoteMultipleForm(request.GET)
        if form.is_valid():
            classe = form.cleaned_data.get('classe')
            matiere = form.cleaned_data.get('matiere')
            
            # Filtre sur les élèves de la classe
            eleves = Eleve.objects.filter(classe=classe)
            
            # Filtre supplémentaire sur la matière si spécifiée
            if matiere:
                notes = Note.objects.filter(eleve__in=eleves, matiere=matiere)
            else:
                notes = Note.objects.filter(eleve__in=eleves)
    else:
        form = NoteMultipleForm()
    
    return render(request, 'responsable_filiere/note_list.html', {
        'form': form,
        'notes': notes
    })

def note_create(request):
    """Création d'une note individuelle"""
    if request.method == 'POST':
        form = NoteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('responsable_filiere:note_list')
    else:
        form = NoteForm()
    
    return render(request, 'responsable_filiere/note_form.html', {'form': form})

def note_class_create(request):
    """Création de notes pour une classe entière"""
    if request.method == 'POST':
        form = NoteMultipleForm(request.POST)
        if form.is_valid():
            classe = form.cleaned_data['classe']
            matiere = form.cleaned_data['matiere']
            date = form.cleaned_data['date']
            type_eval = form.cleaned_data['type_evaluation']
            
            # On récupère tous les élèves de la classe
            eleves = Eleve.objects.filter(classe=classe)
            
            # On préremplit un formulaire pour chaque élève
            initial_data = [{'eleve': eleve.id, 'matiere': matiere.id, 
                           'date': date, 'type_evaluation': type_eval} 
                          for eleve in eleves]
            
            # On crée un formset avec ces données initiales
            NoteFormSet = formset_factory(NoteForm, extra=0)
            formset = NoteFormSet(initial=initial_data)
            
            return render(request, 'responsable_filiere/note_class_form.html', {
                'formset': formset,
                'classe': classe,
                'matiere': matiere,
                'date': date,
                'type_evaluation': type_eval
            })
    else:
        form = NoteMultipleForm()
    
    return render(request, 'responsable_filiere/note_multiple_form.html', {'form': form})

def save_class_notes(request):
    """Sauvegarde des notes pour tous les élèves d'une classe"""
    if request.method == 'POST':
        NoteFormSet = formset_factory(NoteForm, extra=0)
        formset = NoteFormSet(request.POST)
        
        if formset.is_valid():
            for form in formset:
                if form.cleaned_data.get('valeur'):  # Ne sauvegarde que si une note est entrée
                    form.save()
            
            return redirect('responsable_filiere:note_list')
        else:
            return render(request, 'responsable_filiere/note_class_form.html', {'formset': formset})
    
    return redirect('responsable_filiere:note_class_create')

# Génération de bulletins (sans @login_required)
def generer_bulletin(request, eleve_id):
    """Génère un bulletin de notes au format Excel pour un élève"""
    eleve = get_object_or_404(Eleve, pk=eleve_id)
    notes = Note.objects.filter(eleve=eleve).select_related('matiere')
    
    # Création d'un DataFrame pandas
    data = []
    for note in notes:
        data.append({
            'Matière': note.matiere.nom,
            'Code': note.matiere.code,
            'Coefficient': note.matiere.coefficient,
            'Note': float(note.valeur),
            'Type': note.type_evaluation,
            'Date': note.date,
            'Commentaire': note.commentaire
        })
    
    if not data:
        return HttpResponse("Aucune note disponible pour cet élève")
    
    df = pd.DataFrame(data)
    
    # Calcul de la moyenne par matière
    moyennes = df.groupby(['Matière', 'Code', 'Coefficient']).agg({'Note': 'mean'}).reset_index()
    
    # Calcul de la moyenne générale pondérée par les coefficients
    if not moyennes.empty:
        moyennes['Note_ponderee'] = moyennes['Note'] * moyennes['Coefficient']
        moyenne_generale = moyennes['Note_ponderee'].sum() / moyennes['Coefficient'].sum()
    else:
        moyenne_generale = 0
    
    # Création du fichier Excel
    output = BytesIO()
    workbook = xlsxwriter.Workbook(output)
    
    # Formats
    header_format = workbook.add_format({
        'bold': True,
        'font_color': 'white',
        'bg_color': '#4472C4',
        'border': 1
    })
    
    cell_format = workbook.add_format({
        'border': 1
    })
    
    title_format = workbook.add_format({
        'bold': True,
        'font_size': 16,
        'align': 'center',
        'valign': 'vcenter'
    })
    
    # Feuille principale - Bulletin
    worksheet = workbook.add_worksheet("Bulletin")
    
    # Titre
    worksheet.merge_range('A1:G1', f"BULLETIN DE NOTES - {eleve.nom} {eleve.prenom}", title_format)
    
    # Informations sur l'élève
    worksheet.write('A3', "Nom:", cell_format)
    worksheet.write('B3', eleve.nom, cell_format)
    worksheet.write('A4', "Prénom:", cell_format)
    worksheet.write('B4', eleve.prenom, cell_format)
    worksheet.write('A5', "Classe:", cell_format)
    worksheet.write('B5', eleve.classe.niveau, cell_format)
    
    # En-têtes du tableau de notes
    worksheet.write('A7', "Matière", header_format)
    worksheet.write('B7', "Code", header_format)
    worksheet.write('C7', "Coefficient", header_format)
    worksheet.write('D7', "Moyenne", header_format)
    
    # Remplissage du tableau avec les moyennes par matière
    row = 7
    for _, matiere_data in moyennes.iterrows():
        row += 1
        worksheet.write(f'A{row}', matiere_data['Matière'], cell_format)
        worksheet.write(f'B{row}', matiere_data['Code'], cell_format)
        worksheet.write(f'C{row}', matiere_data['Coefficient'], cell_format)
        worksheet.write(f'D{row}', round(matiere_data['Note'], 2), cell_format)
    
    # Moyenne générale
    row += 2
    worksheet.write(f'A{row}', "MOYENNE GÉNÉRALE:", header_format)
    worksheet.write(f'D{row}', round(moyenne_generale, 2), header_format)
    
    # Feuille détaillée - Notes par matière
    detail_sheet = workbook.add_worksheet("Détail des notes")
    
    # En-têtes
    detail_sheet.write('A1', "Matière", header_format)
    detail_sheet.write('B1', "Type", header_format)
    detail_sheet.write('C1', "Note", header_format)
    detail_sheet.write('D1', "Date", header_format)
    detail_sheet.write('E1', "Commentaire", header_format)
    
    # Remplissage avec toutes les notes
    row = 1
    for _, note_data in df.iterrows():
        row += 1
        detail_sheet.write(f'A{row}', note_data['Matière'], cell_format)
        detail_sheet.write(f'B{row}', note_data['Type'], cell_format)
        detail_sheet.write(f'C{row}', note_data['Note'], cell_format)
        detail_sheet.write(f'D{row}', note_data['Date'].strftime('%d/%m/%Y'), cell_format)
        detail_sheet.write(f'E{row}', note_data['Commentaire'], cell_format)
    
    # Finalisation du document
    workbook.close()
    output.seek(0)
    
    # Création de la réponse HTTP
    response = HttpResponse(
        output.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename=bulletin_{eleve.nom}_{eleve.prenom}.xlsx'
    
    return response

# Vue pour consulter les informations pédagogiques (sans @login_required)
def infos_pedagogiques(request):
    """Vue pour consulter les informations pédagogiques (cahiers de texte, absences, projets)"""
    # Récupération de tous les cahiers de texte, absences et projets
    cahiers = CahierTexte.objects.select_related('classe', 'matiere').order_by('-date')[:10]
    absences = Absence.objects.select_related('eleve').order_by('-date')[:10]
    projets = Projet.objects.select_related('classe', 'matiere').order_by('date_limite')
    
    # Formulaire de filtrage
    form = EleveSelectForm(request.GET or None)
    
    if form.is_valid():
        classe = form.cleaned_data.get('classe')
        if classe:
            cahiers = cahiers.filter(classe=classe)
            absences = absences.filter(eleve__classe=classe)
            projets = projets.filter(classe=classe)
    
    context = {
        'form': form,
        'cahiers': cahiers,
        'absences': absences,
        'projets': projets
    }
    
    return render(request, 'responsable_filiere/infos_pedagogiques.html', context)