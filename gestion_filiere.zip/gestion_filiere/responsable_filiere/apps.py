from django.apps import AppConfig


class FiliereConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'responsable_filiere'
